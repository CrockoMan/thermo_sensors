import os

os.environ['MODE'] = 'TEST'
