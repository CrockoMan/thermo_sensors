//#define SERVER_IP "192.168.1.42"
//#define SERVER_IP "192.168.0.8:8000"
//#define SERVER_IP "http://jsonplaceholder.typicode.com/users"
#define SERVER_IP "http://192.168.1.157:8000/api/v1/sensors/"
#define MEASUREMENT_ENDPOINT "measurement/"
#define SETTINGS_ENDPOINT "settings/"
#define USER_LOGIN "admin"
#define USER_PASSWORD "1"
#define SENSOR_ID 1


// #define WIFI_SSID "Bonus"
// #define WIFI_PASS "8613335976"
#define WIFI_SSID "Crocko"
#define WIFI_PASS ""